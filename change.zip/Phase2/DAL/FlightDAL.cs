﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using FlightException;
using System.Data.Common;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class FlightDAL
    {
        static SqlConnection sqlConnection = new SqlConnection("data source=NDAMSSQL\\SQLILEARN;initial catalog=Training_13Aug19_Pune;persist security info=True;user id=sqluser;password = sqluser");

        public static bool AddFlightDAL(Flight_BK newFlight)
        {
            bool flightAdded = false;
            try
            {
                SqlCommand sqlCommand = new SqlCommand("InsertFlight_bk", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Name", newFlight.Name);
                sqlCommand.Parameters.AddWithValue("@Destination", newFlight.Destination);
                sqlCommand.Parameters.AddWithValue("@GateNo", newFlight.GateNo);
                sqlCommand.Parameters.AddWithValue("@StatusId", newFlight.StatusId);
                sqlCommand.Parameters.AddWithValue("@TerminalId", newFlight.TerminalId);
                sqlCommand.Parameters.AddWithValue("@Estimated", newFlight.departure.Estimated);
                sqlCommand.Parameters.AddWithValue("@Actual", newFlight.departure.Actual);
                sqlCommand.Parameters.AddWithValue("Scheduled", newFlight.departure.Scheduled);
                sqlConnection.Open();

                int affectedRows = sqlCommand.ExecuteNonQuery();

                sqlConnection.Close();
                if (affectedRows > 0)
                    flightAdded = true;
            }
            catch (FtException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return flightAdded;
        }

        public static bool UpdateFlightDAL(Flight_BK newFlight)
        {
            bool flightAdded = false;
            try
            {

                SqlCommand sqlCommand = new SqlCommand("UpdateFlight_bk", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Name", newFlight.Name);
                sqlCommand.Parameters.AddWithValue("@ID", newFlight.ID);
                sqlCommand.Parameters.AddWithValue("@Destination", newFlight.Destination);
                sqlCommand.Parameters.AddWithValue("@GateNo", newFlight.GateNo);
                sqlCommand.Parameters.AddWithValue("@StatusId", newFlight.StatusId);
                sqlCommand.Parameters.AddWithValue("@TerminalId", newFlight.TerminalId);
                sqlCommand.Parameters.AddWithValue("@Estimated", newFlight.departure.Estimated);
                sqlCommand.Parameters.AddWithValue("@Actual", newFlight.departure.Actual);
                sqlCommand.Parameters.AddWithValue("Scheduled", newFlight.departure.Scheduled);
                sqlConnection.Open();
                int affectedRows = sqlCommand.ExecuteNonQuery();
                if (affectedRows > 0)
                    flightAdded = true;
                sqlConnection.Close();
            }
            catch (FtException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return flightAdded;
        }

        public static bool DeleteFlightDAL(int flightId)
        {
            bool flightDeleted = false;
            try
            {
                SqlCommand sqlCommand = new SqlCommand("DeleteFlight_bk", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@ID", flightId);
                sqlConnection.Open();

                int affectedRows = sqlCommand.ExecuteNonQuery();
                if (affectedRows > 0)
                    flightDeleted = true;
                sqlConnection.Close();
            }
            catch (FtException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return flightDeleted;
        }

        public static List<Flight_BK> GetAllFlightsDAL()
        {
            List<Flight_BK> flightList = new List<Flight_BK>();
            try
            {
                SqlCommand sqlCommand = new SqlCommand("GetAllFlights_bk", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlConnection.Open();
                SqlDataReader reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                {
                    Flight_BK flight = new Flight_BK();
                    flight.Name = reader[1].ToString();
                    flight.Destination = reader[2].ToString();
                    flight.departure.ID = Convert.ToInt32(reader[3]);
                    flight.TerminalId = Convert.ToInt32(reader[4]);
                    flight.GateNo = reader[5].ToString();
                    flight.StatusId = Convert.ToInt32(reader[6]);
                    flight.departure.Scheduled = DateTime.Parse(reader[8].ToString());
                    flight.departure.Estimated = DateTime.Parse(reader[9].ToString());
                    flight.departure.Actual = DateTime.Parse(reader[10].ToString());

                    flightList.Add(flight);
                }

                reader.Close();
                sqlConnection.Close();
                return flightList;

            }
            catch (FtException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return flightList;
        }
    }
}
